import { Movies } from './features/movies/Movies';

function App() {
  return (
    <div className="App">
      <Movies />
    </div>
  );
}

export default App;
