/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      backgroundImage: {
        'nav-img': "url('./../public/resources/Slices/nav_bar.png')",
        'placeholder-img': "url('./../public/resources/Slices/placeholder_for_missing_posters.png')",
      },
      height: {
        '192px': '192px',
        '132px': '132px',
      },
      spacing: {
        '30px': '30px',
        '36px': '36px',
        '24px': '24px',
      },
      gap: {
        '30px': '30px',
        '90px': '90px',
      },
      fontSize: {
        '36pt': '36pt',
        '24pt': '24pt',
        '18pt': '18pt',
        '12pt': '12pt',
      },
      minWidth: {
        'xs': '320px',
      }

    },
  },
  plugins: [],
}
